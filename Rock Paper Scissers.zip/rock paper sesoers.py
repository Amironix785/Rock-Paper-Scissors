import tkinter as tk
from PIL import Image , ImageTk
import random
import pygame

pygame.mixer.init()
win  = pygame.mixer.Sound("victory.mp3")
lose = pygame.mixer.Sound("losing.mp3")

pc_score = 0
user_score = 0

win_score = 5






def check_win():
      if user_score >= win_score :
        l_p_score.config(text=f"Pc Have {pc_score} Score")
        l_u_score.config(text=f"{username} Have {user_score} Score")

        l_win.config(text=f"{username} Win")
        win.play()
        screen.after(11000, screen.destroy)

      if pc_score >= win_score :
        l_p_score.config(text=f"Pc Have {pc_score} Score")
        l_u_score.config(text=f"{username} Have {user_score} Score")
        l_win.config(text="pc Win")
        lose.play()
        screen.after(7000, screen.destroy)



def rock_func():
    global user 
    global pc_choice_tk
    global pc_score
    global user_score
    l7=tk.Label(screen,bg="blue",image=rock_tk)
    l7.place(x=300,y=200,anchor="center")
    aks=["paper.jpg","rock.jpg","scissers.jpg"]
    pc_choice=random.choice(aks)
    pc_choice_i=Image.open(pc_choice).resize((90,100))
    pc_choice_tk=ImageTk.PhotoImage(pc_choice_i)
    l5=tk.Label(screen,image=pc_choice_tk)
    l5.place(x=400,y=200,anchor="center")

    if pc_choice=="paper.jpg":
        pc_score+=1
        l_p_score.config(text=f"Pc Have {pc_score} Score ")

    elif pc_choice=="scissers.jpg":
        user_score+=1
        l_u_score.config(text=f"{username} Have {user_score} Score ")

    check_win()


def paper_func():
    global user 
    global pc_choice_tk
    global pc_score
    global user_score
    l7=tk.Label(screen,bg="blue",image=paper_tk)
    l7.place(x=300,y=200,anchor="center")
    aks=["paper.jpg","rock.jpg","scissers.jpg"]
    pc_choice=random.choice(aks)
    pc_choice_i=Image.open(pc_choice).resize((90,100))
    pc_choice_tk=ImageTk.PhotoImage(pc_choice_i)
    l5=tk.Label(screen,image=pc_choice_tk)
    l5.place(x=400,y=200,anchor="center")

    if pc_choice=="scissers.jpg":
        pc_score+=1
        l_p_score.config(text=f"Pc Have {pc_score} Score ")

    elif pc_choice=="rock.jpg":
        user_score+=1
        l_u_score.config(text=f"{username} Have {user_score} Score ")

    check_win()


def scisser_func():
    global pc_choice_tk
    global user 
    global pc_score
    global user_score
    l7=tk.Label(screen,bg="blue",image=scissers_tk)
    l7.place(x=300,y=200,anchor="center")
    aks=["paper.jpg","rock.jpg","scissers.jpg"]
    pc_choice=random.choice(aks)
    pc_choice_i=Image.open(pc_choice).resize((90,100))
    pc_choice_tk=ImageTk.PhotoImage(pc_choice_i)
    l5=tk.Label(screen,image=pc_choice_tk)
    l5.place(x=400,y=200,anchor="center")

    if pc_choice=="rock.jpg":
        pc_score+=1
        l_p_score.config(text=f"Pc Have {pc_score} Score ")

    elif pc_choice=="paper.jpg":
        user_score+=1
        l_u_score.config(text=f"{username} Have {user_score} Score ")

    check_win()


def game_page():
    global name 
    global username
    global rock_tk
    global paper_tk
    global scissers_tk
    global pc_score
    global user_score
    global l_win
    global l_u_score
    global l_p_score
    username= name.get()
    for i in screen.winfo_children():
        i.destroy()

    rock=Image.open("rock.jpg").resize((90,100))
    rock_tk=ImageTk.PhotoImage(rock)

    paper=Image.open("paper.jpg").resize((90,100))
    paper_tk=ImageTk.PhotoImage(paper)

    scissers=Image.open("scissers.jpg").resize((90,100))
    scissers_tk=ImageTk.PhotoImage(scissers)

    b1=tk.Button(screen,bg="sky blue",image=rock_tk,command=rock_func)
    b1.place(x=100,y=100,anchor="center")

    b2=tk.Button(screen,bg="sky blue",image=paper_tk,command=paper_func)
    b2.place(x=100,y=200,anchor="center")

    b3=tk.Button(screen,bg="sky blue",image=scissers_tk,command=scisser_func)
    b3.place(x=100,y=300,anchor="center")

    l_win=tk.Label(screen,bg="yellow",fg="red",text=" ",font=("",18))
    l_win.place(x=350,y=400,anchor="center")

    l_u_score=tk.Label(screen,bg="sky blue",text=f"{username} Have {user_score} Score ")
    l_u_score.place(x=100,y=500)

    l_p_score=tk.Label(screen,bg="sky blue",text=f"Pc Have {pc_score} Score ")
    l_p_score.place(x=600,y=500)

    l1=tk.Label(screen,bg="blue",image=rock_tk)
    l1.place(x=600,y=100,anchor="center")

    l2=tk.Label(screen,bg="blue",image=paper_tk)
    l2.place(x=600,y=200,anchor="center")

    l3=tk.Label(screen,bg="blue",image=scissers_tk)
    l3.place(x=600,y=300,anchor="center")


screen=tk.Tk()
screen.geometry("800x550")
screen.title("Rock Paper Scissors")
screen.config(bg="yellow")
name = tk.StringVar()

e_name=tk.Entry(screen, textvariable=name)
e_name.pack(pady=50)

b_submit=tk.Button(screen,text="submit",command=game_page)
b_submit.pack()


screen.mainloop()